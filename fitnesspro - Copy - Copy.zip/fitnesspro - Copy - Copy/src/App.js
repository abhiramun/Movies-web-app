import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './Components/Header/Header';
import Home from './Pages/Home/Home';
import Movielist from './Components/Movielist/Movielist';
import Details from './Pages/Details/Details';
import Footer from './Components/Footer/Footer';
import Error from './Pages/Error/Error';
import VideoPage from './Pages/Video/VideoPage';
import Reviewpage from './Pages/Reviewpage/Reviewpage';
import Results from './Pages/Results/Results';



function App() {
  return (
    <div className="App">
     <Router>
      <Header/>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/results" element={<Results/>} />
          <Route path="/results/movie/:id" element={<Details/>}/>
          <Route path="movie/:id" element={<Details/>}/>
          <Route path="movies/:type/movie/:id/reviews" element={<Reviewpage/>}/>
          <Route path="movie/:id/reviews" element={<Reviewpage/>}/>
          <Route path="movies/:type/movie/:id" element={<Details/>}/>
          <Route path="movies/:type" element={<Movielist/>}/>
          <Route path="movies/:type/movie/:id/videos" element={<VideoPage/>} /> 
          <Route path="movie/:id/videos" element={<VideoPage/>} />
          <Route path="/*" element={<Error/>}/>

        </Routes>
      <Footer/>
     </Router>
    </div>
  );
}

export default App;
