import React from 'react'
import "./Header.css"
import { Link } from 'react-router-dom'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Catagory from '../Catagory/Catagory';



const Header = () => {
  return (
   
    <div className='header'>
     
    <Navbar bg="transparent" className="Navbar" data-bs-theme="light" fixed="top">
      <Container>
        <Navbar.Brand> 
        <Link to="/"><img className='header_icon' src={require("./logo.png")} alt="Logo" /></Link>  
        </Navbar.Brand>
        <Nav className="me-auto ">
          <Nav.Link href="/" className='navlink m-2'>Home</Nav.Link>
          <Nav.Link href="/movies/now_playing" className='navlink m-2'>Now Playing</Nav.Link>
          <Nav.Link className='navlink mx-2 mt-1'><Catagory/></Nav.Link>
          
          
          
        </Nav>
      </Container>
    </Navbar>
  


       
      
        {/* <Link to="/movies/top_rated">Top Rated</Link>
        <Link to="/movies/upcoming">Upcoming</Link> */}
      
    </div>
  )
}

export default Header
