import React from 'react';
import './Pagination.css';

const Pagination = ({ currentPage, totalPages, handlePrevPage, handleNextPage }) => {
    return (
        <div className="pagination">
            <button onClick={handlePrevPage} disabled={currentPage === 1}>&laquo; Prev</button>
            <div className="pagination-info">{`${currentPage} of ${totalPages}`}</div>
            <button onClick={handleNextPage} disabled={currentPage === totalPages}>Next &raquo;</button>
        </div>
    );
};

export default Pagination;