



import 'react-loading-skeleton/dist/skeleton.css'
import React, { useEffect, useState } from 'react';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import "./Card.css";
import { Link } from 'react-router-dom';

const Card = ({ movie }) => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);
  }, []);

  return (
    <div>
      { 
        isLoading
            ? (
        <div className='cards'>
          <SkeletonTheme baseColor="#616189" highlightColor='#252544'>
            <Skeleton height={300} duration={2} />
          </SkeletonTheme>
          
        </div>
    
      ) : (
        <Link to={`movie/${movie.id}`} style={{ textDecoration: "none", color: "white" }}>
          <div className="cards">
            <img className='cards_img' src={`https://image.tmdb.org/t/p/original${movie.poster_path}`} alt={movie.original_title} />
            <div className='cards_overlay'>
              <div className='cards_title'>{movie.original_title}</div>
              <div className='cards_runtime'>{movie.release_date}</div>
              <div className='cards_description'>{movie.overview.slice(0, 118) + "..."}</div>
            </div>
          </div>
        </Link>
      )}
    </div>
  );
};

export default Card;
