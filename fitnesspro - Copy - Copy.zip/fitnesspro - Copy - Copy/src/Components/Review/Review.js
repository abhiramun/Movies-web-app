import React, { useEffect, useState } from 'react';
import "./Review.css";
import { Link } from 'react-router-dom';

const Review = ({ movie }) => {
    const [reviewDetails, setReviewDetails] = useState(false);

    useEffect(() => {
        // Check if 'movie' exists and has an 'id' property
        if (movie && movie.id) {
            setReviewDetails(true);
        }
    }, [movie]); // Add 'movie' as a dependency to the useEffect hook

    return (
        <div className="review-btn-div">
            {reviewDetails && (
                <Link to={`movie/${movie.id}/reviews`} style={{ textDecoration: "none" }}>
                    <div className="review-btn">
                        Review
                    </div>
                </Link>
            )}
        </div>
    );
}

export default Review;
