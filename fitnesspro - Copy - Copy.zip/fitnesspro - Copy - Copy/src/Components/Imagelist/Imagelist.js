import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import "./Imagelist.css"


const Imagelist = () => {

    const fetch = require('node-fetch');
    const {id} = useParams();


    const url = `https://api.themoviedb.org/3/movie/${id}/images`;
    const options = {
        method: 'GET',
        headers: {
          accept: 'application/json',
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
        }
      };

      const [ImageList, setImageList] = useState([])

      useEffect(()=>{
        getData()
      }, [])


      useEffect(()=>{
        getData()

    },[id])

    const getData = ()=> {

      fetch(url, options)
        .then(res => res.json())
        .then(data => setImageList(data))
        .catch(err => console.error('error:' + err));
    }


  return (
    <div className='movie_lists mt-5 pt-5'>
        <div className='movie_cat'>
            <h1 className='list_title'> IMAGE GALLERY </h1>
            <hr />
        </div>
        <div className='container imglist_cards mt-5'>
            {
             ImageList && ImageList.backdrops && ImageList.backdrops.map (image => (
                <div key={image.id} className=' image_card'>
                    <img className='image-fluid' src={`https://image.tmdb.org/t/p/original${image.file_path}`} alt={image.file_path} />
                </div>
            ))}
        </div>
    </div>


  
  )
}

export default Imagelist



