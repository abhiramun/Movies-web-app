
import React, { useEffect, useState } from 'react';
import Card from '../Card/Card';
import Pagination from '../Pagination/Pagination';
import './Movielist.css';
import { useParams } from 'react-router-dom';

const Movielist = () => {
    const { type } = useParams();
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [movielist, setMovielist] = useState([]);

    useEffect(() => {
        getData();
    }, [type, currentPage]);

    const getData = () => {
        const fetch = require('node-fetch');
        const url = `https://api.themoviedb.org/3/movie/${type ? type : "popular"}?language=en-US&page=${currentPage}`;
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
            }
        };

        fetch(url, options)
            .then(res => res.json())
            .then(data => {
                setMovielist(data.results);
                setTotalPages(data.total_pages);
            })
            .catch(err => console.error('error:' + err));
    };

    const handleNextPage = () => {
        setCurrentPage(prevPage => prevPage + 1);
    };

    const handlePrevPage = () => {
        if (currentPage > 1) {
            setCurrentPage(prevPage => prevPage - 1);
        }
    };

    return (
        <div className='movie_list mt-5 pt-5'>
            <div className='movie_cat'>
                <h1 className='list_title '>{(type ? type : "POPULAR").toUpperCase()} MOVIES</h1>
                <hr />
            </div>
            <div className='container list_cards mt-5'>
                {movielist.map(movie => (
                    <Card key={movie.id} movie={movie} />
                ))}
            </div>
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                handlePrevPage={handlePrevPage}
                handleNextPage={handleNextPage}
            />
        </div>
    );
};

export default Movielist;
