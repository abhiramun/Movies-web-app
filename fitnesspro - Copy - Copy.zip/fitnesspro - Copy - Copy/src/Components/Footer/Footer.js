import React from 'react'
import './Footer.css'; 
import 'bootstrap/dist/css/bootstrap.min.css'; 


const Footer = () => {
  return (
    <footer className="footer mt-5">
            <div >
                <p>&copy; {new Date().getFullYear()} Moviezz. All rights reserved.</p>
            </div>
        
</footer>
);
};

export default Footer
