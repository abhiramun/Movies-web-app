
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SearchComponent.css';

const SearchComponent = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch(`https://api.themoviedb.org/3/search/movie?include_adult=false&language=en-US&page=1&query=${searchTerm}`, {
        method: 'GET',
        headers: {
          accept: 'application/json',
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
        }
      });
      const data = await response.json();
      setIsLoading(false);
      navigate('/results', { state: { searchResults: data.results || [] } });
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoading(false);
    }
  };

  return (
    <div className="search-container container mt-5">
      <h1 id="heading">WELCOME</h1>
      <h5>Dive into an endless world of cinematic wonders, 
        where millions of movies await your discovery.</h5>
      <div className='form-wrap mt-4'>
          <form onSubmit={handleSubmit} className="search-form">
              <input className='search-box' type="text" value={searchTerm} onChange={handleChange} placeholder="Search for a movie..." />
              <button  className="search-btn mx-3" type="submit">Search</button>
              
          </form>
          {isLoading && <p>Loading...</p>}
      </div>
      
    </div>
  );
};

export default SearchComponent;
