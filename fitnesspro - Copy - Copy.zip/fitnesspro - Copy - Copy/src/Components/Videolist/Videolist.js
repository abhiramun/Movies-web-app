
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import "./Videolist.css";

const Videolist = () => {
    const { id } = useParams();
    const [videos, setVideos] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch(`https://api.themoviedb.org/3/movie/${id}/videos?language=en-US`, {
                    method: 'GET',
                    headers: {
                        accept: 'application/json',
                        Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch data');
                }

                const data = await response.json();
                setVideos(data.results);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, [id]);

    return (
        <div className='video-list mt-5 pt-5'>
            <div className='movie_cat'>
                <h1 className='list_title'>{id.original_title} VIDEO GALLERY</h1>
                <hr />
            </div>
            <div className='container movievid video-cards mt-5'>
                {videos && videos.map(video => (
                    <div key={video.id} className='video-card'>
                        <iframe
                            className='video-fluid'
                            width='560'
                            height='315'
                            src={`https://www.youtube.com/embed/${video.key}`}
                            title={video.name}
                            frameBorder='0'
                            allowFullScreen
                        ></iframe>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Videolist;


