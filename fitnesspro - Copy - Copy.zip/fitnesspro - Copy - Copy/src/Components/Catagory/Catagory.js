import React from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import { Link } from 'react-router-dom';
import './Catagory.css'

const Catagory = () => {
  return (
    <Dropdown>
      <Dropdown.Toggle variant="success" id="dropdown-basic">
      Catagory
      </Dropdown.Toggle>

      <Dropdown.Menu >
        <Dropdown.Item className='dropdown-cat' as={Link} to="/movies/popular">Popular</Dropdown.Item>
        <Dropdown.Item className='dropdown-cat' as={Link} to="/movies/top_rated">Top Rated</Dropdown.Item>
        <Dropdown.Item className='dropdown-cat' as={Link} to="/movies/upcoming">Upcoming</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
}

export default Catagory;

