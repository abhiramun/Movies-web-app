import React, { useEffect, useState } from 'react'
import "./Home.css"
import "../../App.css"
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { Link } from 'react-router-dom';
import Movielist from '../../Components/Movielist/Movielist';
import SearchComponent from '../../Components/SearchComponent/SearchComponent';


const Home = () => {

    const truncateText = (text, maxLength) => {
        if (!text) return '';
      
        const words = text.split(' '); 
        if (words.length <= maxLength) return text;
      
        return words.slice(0, maxLength).join(' ') + '...'; 
    };
      

    const [ popularMovies, setPopularMovies ] = useState([])

    const fetch = require('node-fetch');

    let url = 'https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc';
    let options = {
    method: 'GET',
    headers: {
        accept: 'application/json',
        Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
    }
};

    useEffect(()=>{
   
        
        fetch(url, options)
        .then(res => res.json())
        .then(data => setPopularMovies(data.results))
        .catch(err => console.error('error:' + err));
        // .then(data => console.log(data))
    },[]) 

  return (
    <>
        <SearchComponent/>
    <div className='carousel_wrap'>

        
    

            <Carousel className='carousel mt-5'
                showThumbs = {false}
                autoPlay = {true}
                transitionTime={5}
                infiniteLoop={true}
                showStatus={false}

            >
                
                {
                    popularMovies.map(movie =>(
                        <Link style={{textDecoration:"none",color:"white"}} to={`/movie/${movie.id}`}>
                            <div className='carousel_thumb'>
                                <img src={`https://image.tmdb.org/t/p/original${movie && movie.backdrop_path}`} />
                            </div>
                            <div className='carousel_overlay'>
                                <div className='carousel_title'><h1>{movie ? movie.original_title: ""}</h1></div>
                                <div className='carousel_runtime'>
                                    {movie ? movie.release_date : ""}
                                    <br></br>
                                    <span className='carousel_rating'>
                                        {movie ? movie.vote_average : ""}
                                        <span class="material-symbols-outlined">
                                            star
                                            </span>{""}
                                    </span>
                                </div>
                                <div className='carousel_description'>
                                    <p>{truncateText(movie ? movie.overview : "", 20)}</p>
                                </div>

                            </div>
                        </Link>
                    ))
                }
                
                
            </Carousel>
            <Movielist/>
  
    </div>
    </>
  )
}

export default Home
