



import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
    
const VideoPage = () => {

    const fetch = require('node-fetch');
    const { id } = useParams();
    const [videos, setVideos] = useState([]);


    const url = `https://api.themoviedb.org/3/movie/${id}/videos?language=en-US`;
    const options = {
        method: 'GET',
        headers: {
          accept: 'application/json',
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNWIyZTA0YmE2NjZmMmM3NzgxOTdhNDBlNmFlNzk1MyIsInN1YiI6IjY2Mzg2MDdiMmZhZjRkMDEyN2M2MmIyZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.PwdYae_i-cDmJzqhTDICUSpwDdm1-hyYWV_sKxHpZuk'
        }
      };
      
      useEffect(()=>{
        getData()
      }, [])


      useEffect(()=>{
        getData()

    },[id])

    const getData = ()=> {

        fetch(url, options)
        .then(res => res.json())
        .then(data => setVideos(data))
        .catch(err => console.error('error:' + err));

      }

      

    return (
        <div className='video-list mt-5 pt-5'>
        <div className='video-cat'>
            <h1 className='list-title'>{id} Videos</h1>
            <hr />
        </div>
        <div className='container video-cards mt-5'>
            {videos && videos.map(video => (
                <div key={video.id} className='video-card'>
                    <iframe
                        className='video-fluid'
                        width='560'
                        height='315'
                        src={`https://www.youtube.com/embed/${video.key}`}
                        title={video.name}
                        frameBorder='0'
                        allowFullScreen
                    ></iframe>
                </div>
            ))}
        </div>
        </div>
      )
    }
    
export default VideoPage
    
