import React from 'react'
import { useLocation } from 'react-router-dom';
import './Results.css';
import Card from '../../Components/Card/Card';




const Results = () => {

    const location = useLocation();
    const { searchResults } = location.state;
  
  return (
    <div className="results-container container-fluid mt-5 pt-5">
        <hr></hr>
        
    <h1>your search results</h1>
    <hr></hr>
    <div className="search-results container">
    {searchResults.map((movie) => (
        <Card key={movie.id} movie={movie} />
      ))}
    </div>
  </div>
);
};

export default Results

