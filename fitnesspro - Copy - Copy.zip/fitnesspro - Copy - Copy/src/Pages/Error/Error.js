import React from 'react'
import "./Error.css"


const Error = () => {
  return (
    <div className='container errorpage'>

        <div className='error_img'>
            <img src='errorimg.jpg' alt='error' height={300} width={500} />

        </div>
        <div>
            
        </div>


      
    </div>
  )
}

export default Error
